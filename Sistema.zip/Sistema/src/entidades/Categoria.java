
package entidades;

public class Categoria {
    private int id;
    private String descripcion;
    private String nombre;
    private boolean activo;   

    
    //Constructores
    public Categoria() {
    }

    public Categoria(int id, String descripcion, String nombre, boolean activo) {
        this.id = id;
        this.descripcion = descripcion;
        this.nombre = nombre;
        this.activo = activo;
    }

    public Categoria(int aInt, String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Propiedades como los atributos son privados estaremos creando propiedades (getter y sette) para poder acceder.

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    //Metodo Tostring

    @Override
    public String toString() {
        return "Categoria{" + "id=" + id + ", descripcion=" + descripcion + ", nombre=" + nombre + ", activo=" + activo + '}';
    }
    
}


