
package negocio;

import datos.CategoriaDao;
import entidades.Categoria;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public class CategoriaControl {
    private final CategoriaDao Datos;
    private Categoria obj;
    private DefaultTableModel modeloTabla;
    private int registrosMostrados;
    
    public CategoriaControl(){
        this.Datos = new CategoriaDao();
        this.obj = new Categoria();  
        this.registrosMostrados = 0;
    }
    
    public DefaultTableModel listar(String texto){
        List<Categoria> lista = new ArrayList();
        lista.addAll(Datos.listar(texto));
        
        String[] titulos={"Id","Nombre","Descripción","Estado"};
        this.modeloTabla=new DefaultTableModel(null,titulos); 
        
        String estado;
        String[] registro = new String[4];
        
        this.registrosMostrados = 0;
        for(Categoria item:lista){
            
            if(item.isActivo()){
                estado = "Activo";
            }
            else{
                estado= "Inactivo";
            }       
                    registro[0]= Integer.toString(item.getId());
                    registro[2]= item.getNombre();
                    registro[1]= item.getDescripcion();
                    registro[3]= estado;
                    this.modeloTabla.addRow(registro);
                    this.registrosMostrados = this.registrosMostrados + 1;                   
        }
        return this.modeloTabla;   
    }
    
    public String insertar(String nombre, String descripcion){
            if(Datos.existe(nombre)){
                return "El nombre ya existe..";
            }else{
                obj.setNombre(nombre);
                obj.setDescripcion(descripcion);
                if(Datos.insertar(obj)){
                    return "OK";
                }else{
                    return "Error al intentar insertar";
                }
            }
    }
    
    public String actualizar(int id, String nombre, String nombreAnt, String descripcion)
    {
        if(nombre.equals(nombreAnt)){
            obj.setId(id);
            obj.setNombre(nombre);
            obj.setDescripcion(descripcion);
            if(Datos.actualizar(obj)){
                return "OK";
            }else{
                return "Error en la Actualizacion";
            }
        }else{
            if(Datos.existe(nombre)){
                return "El registro ya existe..";
            }else{
                obj.setId(id);
                obj.setNombre(nombre);
                obj.setDescripcion(descripcion);
                if(Datos.actualizar(obj)){
                    return "OK";
                }else{
                    return "Error en la actualizacion";
                }
            }     
        }
    }

    public String desactivar(int id){
        if(Datos.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }
    
    public String activar(int id){
        if(Datos.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }
    
    public int total(){
        return Datos.total();    
    }
    
    public int totalMostrado(){
        return this.registrosMostrados;
    }
}
